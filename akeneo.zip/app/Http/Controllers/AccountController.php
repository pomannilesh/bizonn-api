<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;

use App\Models\Kiosk;
use App\Traits\Accounts;
use App\Models\CustomResponse;

class AccountController extends Controller
{
    use Accounts;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(){
        //
    }

    /*  Lists metadata of the machine and its associated user account
     *  Metadata such as associated template, all the machine fields, address details and 
     *  associated user account details such as privacy policy, etc 
     *  
     *  Request Param : identifier , password
     *
     */
    public function register(Request $request){
        $input = $request->account;
        
        $validator = Validator::make($input,[
            'identifier' => 'required',
            'password' => 'required',
        ]);

        if($validator->fails()){
            return response()->json(['status' => false, 'message' => config('app.VALIDATION')]);
        }

        $custom_response = new CustomResponse();
        // check data is exist in kiosks table or not
        
        $kiosks = new Kiosk();
        $kioskDetails = $kiosks->getKiosks($input);
        // if present
        if(!empty($kioskDetails)){
            $seachInput['kiosk_id']         = $kioskDetails->kiosk_id;
            $updateInput['kiosk_status']    = 'Y';
            // update status
            Kiosk::updateorCreate($seachInput, $updateInput);
        }

        $accountDetails = $this->getAccountDetails($input);
        
        if($accountDetails['account_id'] != ''){
            $newAccountDetails = $this->removeGlobalParams($accountDetails);
            return $custom_response->sendResponse($newAccountDetails, '');   
        }elseif (!empty($accountDetails['stripe_private_key']) && $accountDetails['stripe_private_key'] == "stripe_private_key") {
            return $custom_response->sendError(config('app.STRIPE_PRIVATE_KEY_FAIL'), '', 200); 
        }elseif (!empty($accountDetails['acc_status']) && $accountDetails['acc_status'] == "inactive") {
            return $custom_response->sendError(config('app.ACCOUNT_STATUS_FAIL'), '', 200); 
        }elseif (!empty($accountDetails['kiosk_status']) && $accountDetails['kiosk_status'] == "inactive") {
            return $custom_response->sendError(config('app.KIOSK_STATUS_FAIL'), '', 200);   
        }else{   
            return $custom_response->sendError(config('app.ACCOUNT_NOT_FOUND'), '', 200);   
        }
    }
}
