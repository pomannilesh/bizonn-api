<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

use App\Mail\MachineStatus;

use App\Models\Kiosk;
use App\Models\KioskMonitor;
use App\Models\Account;
use App\Models\Cart;
use App\Models\JourneyStep;
use App\Models\Journey;
use App\Models\User;

use App\Traits\Accounts as AccountTrait;
use App\Traits\Optin;
use App\Traits\Catalogue;

class BrowseController extends Controller
{
	use AccountTrait, Optin, Catalogue;

	/* Lists all the products which are assigned to the machine
	 * Special case = If we send cart id as blank and send "dont_create_cart": "N", then it creates 
	 * a new cart id
     * Special case = If we send cart id as blank and send "dont_create_cart": "Y", then it does 
     * not create a new cart id and just shows all the products assigned to the machine
     * Also it accepts age, gender and emotion. And stores it in the journey table against the cart 
     * id
     *  
     * Request Param :- identifier, 
     * password,customer_id,cart_id,dont_create_cart,image,age,gender,emotion
     *
     */
	public function catalogue(Request $request){
		$input = $request->input('account');

		if(!empty($input['identifier']) && !empty($input['password'])){
			$accountData = $this->getAccountDetails($input);
			if(!empty($accountData['account_id']) && $accountData['account_id'] != null){

				// If cart id present
				if (!empty($input['cart_id']) && $input['cart_id'] != NULL) { 
					$getcart = Cart::with('journey')->where('cart_id',$input['cart_id'])->get();

					if($getcart->count() > 0){
						$cart = $getcart->first();
						if (!empty($cart->cart_id) || !empty($cart->journey->customer_id)) {
							$expireJourneyStep = $this->getCartJourney($cart->cart_id);
							if($expireJourneyStep != false){
								if (in_array('checkout', $expireJourneyStep)) {
	                                return response()->json(['status' => FALSE, 'message' => config('app.api_checkout_fail')], 200); // NOT_FOUND (404) being the HTTP response code
	                            }

	                            if (in_array('abandon', $expireJourneyStep)) {
	                                return response()->json(['status' => FALSE, 'message' => config('app.api_abandon_fail')], 200); // NOT_FOUND (404) being the HTTP response code
	                            }
							}else{
    							$accountData['customer_id']     = (string)$cart->customer_id;
	                            $accountData['cart_id']         = (string)$cart->cart_id; 
	                            $catalogdata 					= $accountData;
	                            // if param cart_id exist in db(carts table),then create catalogue event
	                            $cataloguedata = $this->catalogCart($input, $catalogdata);
    						}
						}
					}else{						
						return response()->json(['status' => FALSE, 'message' => config('app.api_cart_found_failure')], 200);
					}
                }else{
                	/* if cart_id not passed in api and but customer_id passed in api */
                    // if cart_id not exist and customer id is exist
                    if (!empty($input['customer_id']) && $input['customer_id'] != NULL) {
						$customer = $this->get_existing_customer($input['customer_id']);
                        /* if user not pass Y then create cart */    
                        if(strtoupper($input['dont_create_cart'])  !='Y') {
                            $input['dont_create_cart'] = 'N';
                        }

                        $cartdtl 		=  $this->newCart($customer, $accountData, $input['dont_create_cart']);
                        $catalogdata 	= $cartdtl;
                        $cataloguedata 	= $this->catalogCart($input, $catalogdata);
                    }else{

                    	$email = NULL;
                    	if(strtoupper($input['dont_create_cart'])  !='Y') {
                            $input['dont_create_cart'] = 'N';
                        } else {
                           $cataloguedata = $this->catalogCart($input, $accountData);
                           $cataloguedata['customer_id'] 	= "";
                           $cataloguedata['cart_id'] 		= "";
                        }

                        if($input['dont_create_cart'] == 'N') {
                            $customer 		= $this->insert_new_customer($email);
                            $cartdtl 		= $this->updateCart($customer, $accountData,$input['dont_create_cart']);
                            $catalogdata 	= $cartdtl;
                            $cataloguedata 	= $this->catalogCart($input, $catalogdata);
                        }
                    }                	
                }

                if (!empty($cataloguedata) && empty($cataloguedata['status'])){
                    $new_cataloguedata = $this->removeGlobalParams($cataloguedata);
                    return response()->json(['status' => TRUE, 'data' => $new_cataloguedata], 200);
                }else{                	
                	return response()->json(['status' => FALSE, 'message' => config('app.api_cart_found_failure')], 200);// NOT_FOUND (404) being the HTTP response code
                }  

			}elseif (!empty($accountData['stripe_private_key']) && $accountData['stripe_private_key'] == "stripe_private_key") {
				return response()->json(['status' => FALSE, 'message' => config('app.api_stripe_private_key_fail')], 200);
			}elseif (!empty($accountData['enddate']) && $accountData['enddate'] == "enddate") {    
                return response()->json(['status' => FALSE, 'message' => config('app.api_enddate_fail')], 200);
            }elseif (!empty($accountData['acc_status']) && $accountData['acc_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_acc_status_fail')], 200);
            }elseif (!empty($accountData['kiosk_status']) && $accountData['kiosk_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_kiosk_status_fail')], 200);
            }else{
            	return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
            }
		}else{
			return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
		}
	}

	/*  It accepts the cart id and product id as 2 key parameters along with the other details (
	 *  machine credentials, user journey data)
     *  And shows all the variants which are associated with the this product id and assigned to 
     *  this particular machine
     *
     *  Request Param: identifier,password,cart_id,product_id,gender, age,emotion
     */

	public function product(Request $request){
		$input = $request->input('account');

		if(!empty($input['identifier']) && !empty($input['password'])){

			$accountData = $this->getAccountDetails($input);

			if(!empty($accountData['account_id']) && $accountData['account_id'] != null){

				// If cart id present
				if (!empty($input['cart_id']) && $input['cart_id'] != NULL) { 

					$getcart = Cart::with('journey')->where('cart_id', $input['cart_id'])->get();
					
					if($getcart->count() > 0){
						$cart = $getcart->first();
						
						$expireJourneyStep = $this->getCartJourney($cart->cart_id);
						if($expireJourneyStep != false){
							if (in_array('checkout', $expireJourneyStep)) {
                                return response()->json(['status' => FALSE, 'message' => config('app.api_checkout_fail')], 200); // NOT_FOUND (404) being the HTTP response code
                            }
                            if (in_array('abandon', $expireJourneyStep)) {
                                return response()->json(['status' => FALSE, 'message' => config('app.api_abandon_fail')], 200); // NOT_FOUND (404) being the HTTP response code
                            }
						}
						
						$accountData['customer_id']      = $cart->journey->customer_id; //$cart->customer_id;
                        $accountData['cart_id']          = $cart->cart_id; 

                        if (!empty($input['product_id'])) {
                        	$productdata = $this->productCart($input, $accountData);
                        	if($productdata == "no_found"){                        		
                        		return response()->json(['status' => FALSE, 'message' => config('app.api_product_found_failure')], 200);
                        	}elseif (!empty($productdata) && empty($productdata['status'])) {
                        		$new_productdata = $this->removeGlobalParams($productdata);
                                unset($new_productdata['parameter']);
                                return response()->json(['status' => TRUE, 'data' => $new_productdata], 200);
                        	}else{
                        		return response()->json(['status' => FALSE, 'message' => config('app.api_product_found_failure')], 200);
                        	}
                        }else{
                        	return response()->json(['status' => FALSE, 'message' => config('app.api_product_found_failure')], 200);
                        }						
					}else{						
						return response()->json(['status' => FALSE, 'message' => config('app.api_cart_found_failure')], 200);
					}
                }else{
                	/* if cart_id not passed in api and but customer_id passed in api */
                    // if cart_id not exist and customer id is exist
                         
                    $this->set_response(['status' => FALSE, 'message' => $this->lang->line('api_cart_found_failure_product')], REST_Controller::HTTP_OK);                	
                }

			}elseif (!empty($accountData['stripe_private_key']) && $accountData['stripe_private_key'] == "stripe_private_key") {
				return response()->json(['status' => FALSE, 'message' => config('app.api_stripe_private_key_fail')], 200);
			}elseif (!empty($accountData['enddate']) && $accountData['enddate'] == "enddate") {    
                return response()->json(['status' => FALSE, 'message' => config('app.api_enddate_fail')], 200);
            }elseif (!empty($accountData['acc_status']) && $accountData['acc_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_acc_status_fail')], 200);
            }elseif (!empty($accountData['kiosk_status']) && $accountData['kiosk_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_kiosk_status_fail')], 200);
            }else{
            	return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
            }
		}else{
			return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
		}
	}

	/*  In the request it sends the machine identifier, password, product variant, and the new bay 
	 *  assignment
     *  It will update the assigned bay for that product variant to the new bay assignment and give 
     *  me a status message about the success/failure
     *  It also ensures that only the product variant sent in this request is assigned to that bay 
     *  number, all other product variants assigned to that bay number for that machine need to be 
     *  unassigned
     *
     *  Request Param: identifier,password,product_variant_id,bay_number
     */
	public function productbay(Request $request){
		$input = $request->input('account');

		if(!empty($input['identifier']) && !empty($input['password'])){

			$accountData = $this->getAccountDetails($input);
			// dd($accountData);

			if(!empty($accountData['account_id']) && $accountData['account_id'] != null){

				$productBay = $this->changeProductBay($input, $accountData);
				if ($productBay == "product_remove") {
					return response()->json(['status' => TRUE, 'message' => config('app.prod_remove_bay')], 200);
				}elseif ($productBay == "variant_error") {
					return response()->json(['status' => FALSE, 'message' => config('app.invalid_variant_for_machine')], 200);
				}elseif ($productBay == "machine_error") {
					return response()->json(['status' => FALSE, 'message' => config('app.not_allowed_add_bay_to_kiosk')], 200);
				}elseif ($productBay == "invalid_bay") {
					return response()->json(['status' => FALSE, 'message' => config('app.invalid_variant_bay_no')], 200);
				}elseif($productBay == 1){
					return response()->json(['status' => TRUE, 'message' => config('app.variant_bay_no_update_success')], 200);					
				}else{
					return response()->json(['status' => FALSE, 'message' => config('app.variant_not_add_bay')], 200);
				}

			}elseif (!empty($accountData['stripe_private_key']) && $accountData['stripe_private_key'] == "stripe_private_key") {
				return response()->json(['status' => FALSE, 'message' => config('app.api_stripe_private_key_fail')], 200);
			}elseif (!empty($accountData['enddate']) && $accountData['enddate'] == "enddate") {    
                return response()->json(['status' => FALSE, 'message' => config('app.api_enddate_fail')], 200);
            }elseif (!empty($accountData['acc_status']) && $accountData['acc_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_acc_status_fail')], 200);
            }elseif (!empty($accountData['kiosk_status']) && $accountData['kiosk_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_kiosk_status_fail')], 200);
            }else{
            	return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
            }
		}else{
			return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
		}
	}

	/*  In the request it sends the machine identifier, password, product variant, and the new 
	 *  quantity
     *  It will update the quantity for that product variant to the new quantity and gives a status 
     *  message about the success/failure
     *
     *  Request Param: identifier,password,product_variant_id,bay_number
     */
	public function productquantity(Request $request){
		$input = $request->input('account');

		if(!empty($input['identifier']) && !empty($input['password'])){

			$accountData = $this->getAccountDetails($input);
			if ($input['quantity'] < 0){
				return response()->json(['status' => FALSE, 'message' => 'Quantity should be a positive integer only'], 200);
			}else if(is_float($input['quantity']) == true){
				return response()->json(['status' => FALSE, 'message' => 'Quantity should be a positive integer only'], 200); 
	        }elseif(!empty($accountData['account_id']) && $accountData['account_id'] != null){
				$productBay = $this->changeProductQty($input, $accountData);
				if ($productBay == "invalid_bay") {
					return response()->json(['status' => FALSE, 'message' => config('app.wrong_bay')], 200);
				}elseif($productBay == 0){
					return response()->json(['status' => FALSE, 'message' => config('app.wrong_bay')], 200);
				}else{
					return response()->json(['status' => TRUE, 'message' => config('app.variant_quantity_update_success')], 200);
				}
			} elseif (!empty($accountData['stripe_private_key']) && $accountData['stripe_private_key'] == "stripe_private_key") {
				return response()->json(['status' => FALSE, 'message' => config('app.api_stripe_private_key_fail')], 200);
			}elseif (!empty($accountData['enddate']) && $accountData['enddate'] == "enddate") {    
                return response()->json(['status' => FALSE, 'message' => config('app.api_enddate_fail')], 200);
            }elseif (!empty($accountData['acc_status']) && $accountData['acc_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_acc_status_fail')], 200);
            }elseif (!empty($accountData['kiosk_status']) && $accountData['kiosk_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_kiosk_status_fail')], 200);
            }else{
            	return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
            }
		}else{
			return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
		}
	}

	/*  In the request it sends machine id and password
     *  And response is is similar to the catalog api but it shows all the products within this 
     *  account and not specific to the products which are assigned to the machine
     *
     */
	public function allavailableproducts(Request $request){
		$input = $request->input('account');

		if(!empty($input['identifier']) && !empty($input['password'])){
			$accountData = $this->getAccountDetails($input);
			if(!empty($accountData['account_id']) && $accountData['account_id'] != null){

				$account_ids = array();
				$checkParentAccount = Account::where('account_id', $accountData['account_id'])->select('account_id_parent')->get();
				if($checkParentAccount->count() > 0){
					$parentAcc = $checkParentAccount->first();
					if($parentAcc->account_id_parent != 0){
						array_push($account_ids, $parentAcc->account_id_parent);
					}					
				}
				array_push($account_ids, $accountData['account_id']);

				$kioskIds = Kiosk::whereIn('account_id', $account_ids)->select('kiosk_id')->get()->toArray();
				$kisok_ids = array_column($kioskIds, 'kiosk_id');

				$cataloguedata = $this->catalogCart($input, $accountData, $account_ids, 1);

				if (!empty($cataloguedata) && empty($cataloguedata['status'])){
                    $new_cataloguedata = $this->removeGlobalParams($cataloguedata);
                    return response()->json(['status' => TRUE, 'products' => $new_cataloguedata['inventory']], 200);
                }else{                	
                	return response()->json(['status' => FALSE, 'message' => config('app.api_cart_found_failure')], 200);// NOT_FOUND (404) being the HTTP response code
                }
			}elseif (!empty($accountData['stripe_private_key']) && $accountData['stripe_private_key'] == "stripe_private_key") {
				return response()->json(['status' => FALSE, 'message' => config('app.api_stripe_private_key_fail')], 200);
			}elseif (!empty($accountData['enddate']) && $accountData['enddate'] == "enddate") {    
                return response()->json(['status' => FALSE, 'message' => config('app.api_enddate_fail')], 200);
            }elseif (!empty($accountData['acc_status']) && $accountData['acc_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_acc_status_fail')], 200);
            }elseif (!empty($accountData['kiosk_status']) && $accountData['kiosk_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_kiosk_status_fail')], 200);
            }else{
            	return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
            }
		}else{
			return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
		}
	}

	/*  This API helps keep all the machine pings in a big table so we can track the machine status 
	 *  over time
     *  It accepts the machine identifier, password, status, and error message. This endpoint will 
     *  be called by the POS on a 10-minute interval to keep the backend up to date on the current 
     *  status.
     *  “ready” - which means online, operational, and no issues. Error message will be blank for 
     *  this status type
     *  “error” - which means the machine is out of service in some way. Error message will contain 
     *  the error message for this status type
     *  A notification should be sent from the backend depending upon response received over a 
     *  period of time
	 *
	 * Request Param :- identifier,password,status,error_type,error_message
	 */
	public function machinestatus(Request $request){

		if(!empty($request->input('identifier')) && !empty($request->input('password'))){
			$input['identifier'] 	= $request->input('identifier');
			$input['password'] 		= $request->input('password');
			$accountData = $this->getAccountDetails($input);
			if(empty($accountData['account_id']) && $accountData['account_id'] == null){
				return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
			}

			$checkAccount = Kiosk::where('kiosk_identifier', $request->input('identifier'))->first();
			if(empty($checkAccount->account_id) && $checkAccount->account_id == NULL){
				return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
			}else{
				$monitorData = array();
		        $monitorData['monitor_status'] 	= strtolower($request->input('status'));
		        $monitorData['error_message'] 	= $request->input('error_message');
		        $monitorData['error_type'] 		= $request->input('error_type');		       

				$getKioskData = Kiosk::getKioskFromIdentifier($request->input('identifier'));
				if($getKioskData->count() > 0){
					$kiosk = $getKioskData->toArray()[0];
               	 	// get last entry with mail_sent flag 'Y'
                	$kioskMonitor = KioskMonitor::where('kiosk_id', $kiosk['kiosk_id'])->whereNotNull('mail_sent_yn')->orderby('kiosk_monitor_id','DESC')->first();

                	$monitorData['kiosk_id'] 	= $kiosk['kiosk_id'];
                    $monitorData['monitor_dt'] 	= config('app.CURRENTEPOCH');
                    $monitorMsgSave 			= KioskMonitor::create($monitorData);
                    $kiosk_monitor_id 			= $monitorMsgSave->kiosk_monitor_id;

                    $accountDetails = Account::where('account_id', $kiosk['account_id'])->first();
                	$userDetails 	= User::where('account_id', $kiosk['account_id'])->first();

                	if(!empty($kioskMonitor)){
	                    
						if($monitorData['monitor_status']!= $kioskMonitor->monitor_status){
	                        if($monitorData['monitor_status'] == 'error'){
								
								if($kiosk['alert_email_yn'] == 'Y'){
									// sent mail to admin for machine down
									try{										
										$to = config('app.adminMail');
										Mail::to($to)->cc($userDetails->email)->send(new MachineStatus($kiosk, $accountDetails, $monitorData));
									}catch(\Exception $e){
										\Log::info("Machine Alert failed for ".$e);
									}
								}

	                            // update flag
	                            $updateKioskMonitor = KioskMonitor::find($kiosk_monitor_id);
	                            $updateKioskMonitor->mail_sent_yn = 'Y';
	                            $updateKioskMonitor->save();
	                        }

	                        if($monitorData['monitor_status'] == 'ready'){
	                            // sent mail for machine ready
								if($kiosk['alert_email_yn'] == 'Y'){
									try{
										$to = config('app.adminMail');
										Mail::to($to)->cc($userDetails->email)->send(new MachineStatus($kiosk, $accountDetails, $monitorData));
									}catch(\Exception $e){
										\Log::info("Machine ready alert failed for ".$e);
									}
								}

								// update flag
	                            $updateKioskMonitor = KioskMonitor::find($kiosk_monitor_id);
	                            $updateKioskMonitor->mail_sent_yn = 'Y';
	                            $updateKioskMonitor->save();
	                        } 
	                    }

	                }else{

	                    // for first time
                        if($monitorData['monitor_status'] == 'error'){

							if($kiosk['alert_email_yn'] == 'Y'){
								// sent mail to admin for machine down
								try{
									$to = config('app.adminMail');
									Mail::to($to)->cc($userDetails->email)->send(new MachineStatus($kiosk, $accountDetails, $monitorData));
								}catch(\Exception $e){
									\Log::info("Machine Alert failed for ".$e);
								}
							}

                            // update flag
                            $updateKioskMonitor = KioskMonitor::find($kiosk_monitor_id);
                            $updateKioskMonitor->mail_sent_yn = 'Y';
                            $updateKioskMonitor->save();
                        }
	                }
					
					// if($monitorData['monitor_status'] == 'ready'){
					// 	$kiosStatus = KioskMonitor::where('kiosk_id', $kiosk['kiosk_id'])->orderBy('kiosk_monitor_id', 'DESC')->get();
					// 	if($kiosStatus->count() > 0){
					// 		$kiosStatus = $kiosStatus->first();
					// 		if($kiosStatus->monitor_status == 'offline_mail'){
					// 			$this->machine_status_email_get($kiosk , $monitorData);
					// 		}
					// 	}                        
					// }

                    // if($monitorData['monitor_status'] == 'error'){
                    //     $this->machine_status_error_email($kiosk , $monitorData);
                    // }

                    if($monitorMsgSave){
                    	// return response()->json(['status' => TRUE, 'message' => config('app.api_account_machie_status_add')], 200);
						return response()->json(['status' => TRUE], 200);
                    }else{
                    	return response()->json(['status' => FALSE, 'message' => config('app.api_account_machie_status_error')], 200);
                    }
				}else{
					return response()->json(['status' => FALSE, 'message' => config('app.api_account_machie_not_found')], 200);
				}
				return response()->json(['status' => TRUE, 'kiosks' => $getKioskData], 200);
			}
		}else{
    		return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
		}
	}

	/*  It accepts the email id, dont,create,cart id as a key parameters along with the other 
	 *  details (machine credentials)
	 *
     *  It returns a response if a particular email id can get an optin discount or not.
     *  If an email id was never opted in for a machine, it returns success and gives out discount 
     *  at the time of checkout
     *  If an email id was opted in before for a machine, it returns falls and do not give any 
     *  optin discount at the time of checkout.
     *  
     *  Request Param : identifier, password, email, dont_create_cart
     */
	public function optin(Request $request){
		$input = $request->all();
		if(!empty($input['account']['identifier']) && !empty($input['account']['password'])){
			
			$accountData = $this->getAccountDetails($input['account']);

			if(!empty($accountData['account_id']) && $accountData['account_id'] != null){

				$optindata = $this->optinCart($input['account'],$accountData);
				if($optindata == "no_promo"){

					return response()->json(['status' => FALSE, 'message' => config('app.api_optin_found_success')], 200);

				}elseif (!empty($optindata) && $optindata['cart_id'] != NULL){
					$new_optindata = $this->removeGlobalParams($optindata);
                    unset($new_optindata['is_customer']);

                    return response()->json(['status' => TRUE, 'data' => $new_optindata], 200);
                   
				}elseif ($optindata['cart_id'] == NULL) {
                   if($optindata['is_customer'] == 'N') {
                       $new_optindata = $this->removeGlobalParams($optindata);
                       unset($new_optindata['is_customer']);
                       
                       return response()->json(['status' => TRUE, 'data' => $new_optindata], 200);
                   } else {
                   		return response()->json(['status' => FALSE, 'message' => config('app.api_optin_found_success')], 200);
                        // NOT_FOUND (404) being the HTTP response code 
                   }
                    
                }
                else
                {
                    return response()->json(['status' => FALSE, 'message' => config('app.api_optin_found_success')], 200); // NOT_FOUND (404) being the HTTP response code
                }  

			}elseif (!empty($accountData['stripe_private_key']) && $accountData['stripe_private_key'] == "stripe_private_key") {

				return response()->json(['status' => FALSE, 'message' => config('app.api_stripe_private_key_fail')], 200);

			}elseif (!empty($accountData['enddate']) && $accountData['enddate'] == "enddate") {
    
                return response()->json(['status' => FALSE, 'message' => config('app.api_enddate_fail')], 200);

            }elseif (!empty($accountData['acc_status']) && $accountData['acc_status'] == "inactive") {

            	return response()->json(['status' => FALSE, 'message' => config('app.api_acc_status_fail')], 200);

            }elseif (!empty($accountData['kiosk_status']) && $accountData['kiosk_status'] == "inactive") {

            	return response()->json(['status' => FALSE, 'message' => config('app.api_kiosk_status_fail')], 200);

            }else{
            	return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
            }

		}else{
			return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
		}
	}

	/*  
	 *  Used for sending email when machine status getting "errro"
	 */
	private function machine_status_error_email($kioskData, $monitorData){
		$kioskData['machine_status'] 	= $monitorData['monitor_status'];
        $kioskData['error_type'] 		= $monitorData['error_type'];
        $kioskData['error_message'] 	= $monitorData['error_message'];
       // print_r($kioskData); die;
        $result =  Mail::to(config('app.adminMail'))->send(new MachineStatus($kioskData));
	}

	/*  
	 *  Used for sending email when machine status getting "ready"
	 */
	private function machine_status_email_get($kioskData, $monitorData){
		$kioskData['machine_status'] 	= $monitorData['monitor_status'];
        $kioskData['error_type'] 		= null;
        $kioskData['error_message'] 	= null;
        $result = Mail::to(config('app.adminMail'))->send(new MachineStatus($kioskData));        
	}

	/*  It accepts the email id, dont,create,cart id as a key parameters along with the other 
	 *  details (machine credentials)
	 *
     *  It returns a response if a particular email id can get an optin discount or not.
     *  If an email id was never opted in for a machine, it returns success and gives out discount 
     *  at the time of checkout
     *  If an email id was opted in before for a machine, it returns falls and do not give any 
     *  optin discount at the time of checkout.
     *  
     *  Request Param : identifier, password, ad_type, ad_gender, ad_age, ad_emotion
     */
	public function advertisement(Request $request){
		$input = $request->input('account');

		if(!empty($input['identifier']) && !empty($input['password'])){
			$accountData = $this->getAccountDetails($input);
			if(!empty($accountData['account_id']) && $accountData['account_id'] != null){

				$cataloguedata = $this->getAdvertisements($input, $accountData);
				// dd($cataloguedata);

                if (!empty($cataloguedata) && empty($cataloguedata['status'])){
                    $new_cataloguedata = $this->removeGlobalParams($cataloguedata);
                    return response()->json(['status' => TRUE, 'data' => $new_cataloguedata], 200);
                }else{                	
                	return response()->json(['status' => FALSE, 'message' => config('app.api_cart_found_failure')], 200);// NOT_FOUND (404) being the HTTP response code
                }  

			}elseif (!empty($accountData['stripe_private_key']) && $accountData['stripe_private_key'] == "stripe_private_key") {
				return response()->json(['status' => FALSE, 'message' => config('app.api_stripe_private_key_fail')], 200);
			}elseif (!empty($accountData['enddate']) && $accountData['enddate'] == "enddate") {    
                return response()->json(['status' => FALSE, 'message' => config('app.api_enddate_fail')], 200);
            }elseif (!empty($accountData['acc_status']) && $accountData['acc_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_acc_status_fail')], 200);
            }elseif (!empty($accountData['kiosk_status']) && $accountData['kiosk_status'] == "inactive") {
            	return response()->json(['status' => FALSE, 'message' => config('app.api_kiosk_status_fail')], 200);
            }else{
            	return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
            }
		}else{
			return response()->json(['status' => FALSE, 'message' => config('app.api_account_not_valid_req')], 200);
		}
	}

}
  