<?php

namespace App\Traits;
use Auth;

use App\Models\Kiosk;
use App\Models\KioskOptin;
use App\Models\KioskPromo;

use App\Models\Journey;
use App\Models\JourneyStep;

use App\Models\Customer;
use App\Models\Cart;

use App\Models\Orders;

trait Optin {

	public function optinCart($input,$accountData){
		 
		$customer = $this->checkCustomer($input['email'],$accountData);
		if($customer == false){
			return "no_promo";
		}
		if (!empty($customer['is_customer']) && $customer['is_customer'] == 'Y') {
            $cartdtl['cart_id'] = NULL;
            $cartdtl['is_customer'] = 'Y'; 
            return $cartdtl;
        }

        $dont_create_cart = !empty($input['dont_create_cart']) ? $input['dont_create_cart'] : null;
        $cartdtl = $this->updateCart($customer, $accountData, $dont_create_cart);

        $cartdtl['is_customer'] = 'N'; 

        return $cartdtl;
	}

	public function checkCustomer($email,$accountData){

        if(!empty($email)){
        	//print_r($accountData); die;
        	// Getting Kiosk Optin Promo Id
        	$getPromoId = KioskPromo::where(['optin_yn' => 'Y','kiosk_id' => $accountData['kiosk']['acc_kiosk_id']])->select('promo_id')->first();

        	if(empty($getPromoId)){
        		return false;
        	}

        	$promo_id = $getPromoId->promo_id;

            $checkCustomerOptin = KioskOptin::where(['customer_email' => $email,'kiosk_id' => $accountData['kiosk']['acc_kiosk_id'],'optin_promo_id' => $promo_id ])->get();
            if($checkCustomerOptin->count() > 0){
            	$optinData = $checkCustomerOptin->first();
            	$checkCustomerCarts = Journey::where('customer_id',$optinData->customer_id)
            								   ->whereIn('kiosk_id', function($q) use($accountData){
            								   		$q->select('kiosks.kiosk_id')
            								   			->from(with( new Kiosk())->getTable())
            								   			->where('kiosks.account_id',$accountData['account_id']);
            								   })->get();
         		if($checkCustomerCarts->count() > 0){
         			$returnCustomer = [
         				'opt_in_id' => $optinData->kiosk_optin_id,
	                    'customer_id' => $optinData->customer_id,
	                    'email' => $optinData->customer_email,
	                    'created_on' => $optinData->optin_dt,
	                    'is_customer' => 'Y',
	                    'is_cart'   => 'Y',
	                    'promo_id' => $promo_id
         			];
         		}else{
         			$returnCustomer = [
         				'opt_in_id' => $optinData->kiosk_optin_id,
	                    'customer_id' => $optinData->customer_id,
	                    'email' => $optinData->customer_email,
	                    'created_on' => $optinData->optin_dt,
	                    'is_customer' => 'Y',
	                    'is_cart'   => 'Y',
	                    'promo_id' => $promo_id
         			];
         		}
            }else{
            	$returnCustomer = $this->insert_new_customer($email,$accountData['account_id'],$accountData['kiosk']['acc_kiosk_id'],$promo_id);
            	$returnCustomer['is_customer'] = 'N';
            	$returnCustomer['promo_id'] = $promo_id;
            }

            return $returnCustomer;
        }else{
        	return false;
        }
    }


    public function insert_new_customer($email,$account_id=null,$acc_kiosk_id=null,$promo_id=null){

        if(!empty($email)){
            $checkCustomerExists = Customer::where('customer_email',$email)
                                        ->select('customer_id')
                                        ->get();
            $customeExists = $checkCustomerExists->count();
        }else{
            $customeExists = 0;
        }
        
        if($customeExists > 0){
             $newCust = $checkCustomerExists->first();
        }else{
            $newcustinsertdata = array(
                'customer_email' => $email,
                'created_at' => config('app.CURRENTEPOCH')
            );

            $newCust = Customer::create($newcustinsertdata);
        }

    	

    	if(!empty($promo_id)){
    		 $kioskOptinData = array(
	            'customer_id' => $newCust->customer_id,
	            'customer_email' => $email,
	            'kiosk_id' => $acc_kiosk_id,
	            'optin_promo_id' => $promo_id,
	            'optin_dt' => config('app.CURRENTEPOCH')
	        );

	    	$kiosk_optin = KioskOptin::create($kioskOptinData);
	    	$kiosk_optin_id = $kiosk_optin->kiosk_optin_id;
    	}else{
    		$kiosk_optin_id = null;
    	}
    	

    	 $newCustomer = array(
            'opt_in_id' => (!empty($kiosk_optin_id) ? $kiosk_optin_id : 0),
            'customer_id' => $newCust->customer_id,
            'email' => $email,
            'created_on' => config('app.CURRENTEPOCH')
        );
        return $newCustomer;
    }

    public function updateCart($customer, $accountData, $dont_create_cart = null){

    	if(!empty($customer['customer_id'])){
    		$checkCart = Journey::select('carts.cart_id','journeys.customer_id','journeys.kiosk_id')
    							->leftjoin(with(new Cart())->getTable(),'carts.journey_id','journeys.journey_id')
    							->where(['journeys.customer_id' => $customer['customer_id'] , 'journeys.kiosk_id' => $accountData['kiosk']['acc_kiosk_id']])
    							->get();

    		if($checkCart->count() > 0){
    			$customerCart = $checkCart->first();
    			// $expireJourneyStep = JourneyStep::where('cart_id', $customerCart->cart_id)
    			// 							->whereIn('journey_step_name',['checkout','abandon'])
    			// 							->get();
                $expireJourneyStep = Cart::rightjoin(with(new JourneyStep())->getTable(),'journey_steps.journey__id','carts.journey_id')
                        ->select('journey_steps.journey_step_name')
                        ->where('carts.cart_id', $customerCart->cart_id)
                        ->whereIn('journey_steps.journey_step_name',['checkout','abandon'])
                        ->get();
                
    			if($expireJourneyStep->count() > 0){
    				$optin_promo_id = empty($accountData['parameter']['optin_promo_id']) ? 0 : $accountData['parameter']['optin_promo_id'];

    				$journeyinsert = array(
	                    'customer_id' => $customer['customer_id'],
	                    'kiosk_id' => $accountData['kiosk']['acc_kiosk_id'],
	                    'created_at' => config('app.CURRENTEPOCH')
	                );

	                $journey = Journey::create($journeyinsert);
	                if($journey){
	                	$cartData = array(
	                		'journey_id' => $journey->journey_id,
	                		'product_variant_id' => null,
	                		'product_qty' => 0
	                	);
	                	$cart = Cart::create($cartData);
	                	if($cart){
	                		$accountData['customer_id'] = (string) $customer['customer_id'];
                			$accountData['cart_id'] = (string) $cart->cart_id;

                			 if(array_key_exists('promo_id', $customer)){
                                $orderData = [
                                    'journey_id' => $journey->journey_id,
                                    'cart_id' => $cart->cart_id,
                                    'created_at' => config('app.CURRENTEPOCH'),
                                    'promo_id' => $customer['promo_id'],
                                    'dispensed_yn' => 'N'
                                ];

                                Orders::create($orderData);
                            }
	                	}
	                }
    			}else{
                    $checkOrderExist = Orders::where('cart_id',$customerCart->cart_id)
                                              ->select('order_id')
                                              ->get();
                    if($checkOrderExist->count() > 0){
                        $order = $checkOrderExist->first();
                        $updateOrder = Orders::where('order_id',$order->order_id)
                                              ->update(['promo_id' => $customer['promo_id'],'created_at' => config('app.CURRENTEPOCH'),'dispensed_yn' => 'N']);
                    }

    				$accountData['customer_id'] = (string) $customer['customer_id'];
                	$accountData['cart_id'] = (string) $customerCart->cart_id;
    			}
    		}else{
    			if (strtoupper($dont_create_cart) != 'Y') {
    				$journeyinsert = array(
	                    'customer_id' => $customer['customer_id'],
	                    'kiosk_id' => $accountData['kiosk']['acc_kiosk_id'],
	                    'created_at' => config('app.CURRENTEPOCH')
	                );

	                $journey = Journey::create($journeyinsert);
	                if($journey){
	                	$cartData = array(
	                		'journey_id' => $journey->journey_id,
	                		'product_variant_id' => null,
	                		'product_qty' => 0
	                	);
	                	$cart = Cart::create($cartData);
	                	if($cart){
	                		$cart_id = $cart->cart_id;
                            if(array_key_exists('promo_id', $customer)){
                                $orderData = [
                                    'journey_id' => $journey->journey_id,
                                    'cart_id' => $cart->cart_id,
                                    'created_at' => config('app.CURRENTEPOCH'),
                                    'promo_id' => $customer['promo_id'],
                                    'dispensed_yn' => 'N'
                                ];

                                Orders::create($orderData);
                            }
	                		
	                	}else{
	                		$cart_id = null;
	                	}
	                }
    			}else{
    				$cart_id = null;
    			}

    			$accountData['customer_id'] = (string) $customer['customer_id'];
                $accountData['cart_id'] = (string) $cart_id;
    		}
    		return $accountData;

    	}	
    }
}