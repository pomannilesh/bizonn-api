<?php

namespace App\Traits;

use Illuminate\Support\Facades\DB;
use Auth;

use App\Models\Kiosk;
use App\Models\KioskProduct;
use App\Models\KioskOptin;
use App\Models\KioskModel;

use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductVariant;

use App\Models\Journey;
use App\Models\JourneyStep;

use App\Models\Customer;
use App\Models\Cart;

use App\Models\Account;
use App\Models\Ad;

trait Catalogue {

	public function catalogCart($postdata, $catalogdata, $parent_id = null, $flag = null){

		$productData = KioskProduct::select('products.product_name', 'products.product_image', 'products.product_description', 'kiosk_product.kiosk_product_id', 'kiosk_product.product_variant_id', 'product_variants.variant_name', 'kiosk_product.price as variant_price', 'kiosk_product.bay_no', 'kiosk_product.quantity', 'product_variants.variant_sku', 'products.product_id', 'product_variants.product_variant_id')
		->rightjoin(with(new ProductVariant())->getTable(), 'product_variants.product_variant_id', 'kiosk_product.product_variant_id')
		->leftjoin(with(new Product())->getTable(), 'products.product_id', 'product_variants.product_id');
		
		if(empty($parent_id)){
			$productData = $productData->where('kiosk_product.kiosk__id', $catalogdata['kiosk']['acc_kiosk_id']);
		}else{
			$productData = $productData->whereIn('products.account_id', $parent_id);
		}
								   
		$productData 	= $productData->get();
		$productVariant = array();
		$inventory 		= [];
		$bin_identification = $catalogdata['kiosk']['bin_identification'];
		if($productData->count() > 0){
			$products = $productData->all();
			// dd($products);
			foreach ($products as $key => $prod) {				

				$checkProduct = array_search($prod->product_id, array_column($inventory, 'product_id'));
				if($checkProduct !== false){		
					
					//All Available Products
					if(isset($flag) && $flag != ''){

						$checkProductV = array_search($prod->product_variant_id, array_column($inventory[$checkProduct]['variant'], 'variant_id'));

						if($checkProductV !== false){					
							
						}else{
							$variantData = array(
								"variant_id" 	=> (string)$prod->product_variant_id,
								"variant_type" 	=> $prod->variant_sku,
								"variant_name" 	=> $prod->variant_name,
								"quantity" 		=> $prod->quantity,
								"price"			=> $prod->variant_price
							);

							if(empty($parent_id)){
								$variantData["bay_no"] = $bin_identification[$prod->bay_no - 1];
							}

							array_push($inventory[$checkProduct]['variant'], $variantData);
						}

					}else{
						
						//Catalogue Products
						if(empty($parent_id)){
							$checkProductV = array_search($bin_identification[$prod->bay_no - 1], array_column($inventory[$checkProduct]['variant'], 'bay_no'));

							if($checkProductV !== false){
							
							}else{
								$variantData = array(
									"variant_id" 	=> (string)$prod->product_variant_id,
									"variant_type" 	=> $prod->variant_sku,
									"variant_name" 	=> $prod->variant_name,
									"quantity" 		=> $prod->quantity,
									"price"			=> $prod->variant_price
								);
		
								if(empty($parent_id)){
									$variantData["bay_no"] = $bin_identification[$prod->bay_no - 1];
								}
		
								array_push($inventory[$checkProduct]['variant'], $variantData);
							}
						}else{
							$variantData = array(
								"variant_id" 	=> (string)$prod->product_variant_id,
								"variant_type" 	=> $prod->variant_sku,
								"variant_name" 	=> $prod->variant_name,
								"quantity" 		=> $prod->quantity,
								"price"			=> $prod->variant_price
							);

							if(empty($parent_id)){
								$variantData["bay_no"] = $bin_identification[$prod->bay_no - 1];
							}

							array_push($inventory[$checkProduct]['variant'], $variantData);
						}		
					}	
					
				}else{
					$product = array(
						'product_id' 	=> (string)$prod->product_id,
						'product_name' 	=> $prod->product_name,
						'description' 	=> $prod->product_description,
						'media_url' 	=> null,
						'variant' 		=> array()
					);

					if(!empty($prod->product_image)){
						$product['media_url'] = $prod->product_image;
					}else{
						$productImage = ProductImage::where('product_id', $prod->product_id)->select('image_url')->orderBy('product_image_id','desc')->get();
						if($productImage->count() > 0){
							$img 					= $productImage->first();
							$product['media_url'] 	= $img->image_url;
						}
					}

					$variantData = array(
						"variant_id" 	=> (string) $prod->product_variant_id,
						"variant_type" 	=> $prod->variant_sku,
						"variant_name" 	=> $prod->variant_name,
						"quantity" 		=> $prod->quantity,
						"price"			=> $prod->variant_price
					);

					if(empty($parent_id)){
						$variantData["bay_no"] = $bin_identification[$prod->bay_no - 1];
					}

					array_push($product['variant'], $variantData);
					array_push($inventory, $product);
				}
				
			}			
		}

		$catalogdata['inventory'] = $inventory;

		// Check api request from catalagoue
		if(empty($parent_id)){

			if (!empty($catalogdata['cart_id'])) {

				$getJourneyId = Cart::select('journey_id')->where('cart_id', $catalogdata['cart_id'])->first();
	            if(!empty($getJourneyId)){

	                $insertevent = array(
		                'journey_step_dt' 	=> config('app.CURRENTEPOCH'),
		                'journey_step_name' => 'catalogue',
		                'journey__id' 		=> $getJourneyId->journey_id
		            );

		            if (isset($postdata['gender']) && !empty($postdata['gender'])) {
		                $insertevent['journey_gender'] = $postdata['gender'] === "Male" ? 'M' : ($postdata['gender'] === "Female" ? 'F' : 'O');
		            } else {
		                $insertevent['journey_gender'] = null;
		            }

		            $insertevent['journey_age_group'] = (isset($postdata['age']) && !empty($postdata['age'])) ? $this->get_age_group($postdata['age']) : null;

		            if (isset($postdata['emotion']) && !empty($postdata['emotion'])) {
		                $insertevent['journey_emotion_json'] = preg_replace('/\\\"/', "\"", $postdata['emotion']);
		                $insertevent['journey_emotion_json'] = is_array($insertevent['journey_emotion_json']) ? json_encode($insertevent['journey_emotion_json']) : $insertevent['journey_emotion_json']; 
		            } else {
		                $insertevent['journey_emotion_json'] = null;
		            }

		            JourneyStep::create($insertevent);		            
	            }
			}

			if (!empty($catalogdata['customer_id'])) {
	            //$customerdata['photo']             = $postdata['image'];
	            $customerdata['customer_gender'] 	= $insertevent['journey_gender'];
	            $customerdata['customer_age_group'] = $insertevent['journey_age_group'];
	            // $customerdata['emotion'] = $insertevent['emotion'];

	            Customer::where('customer_id', $catalogdata['customer_id'])->update($customerdata);
	        }
	    }

        return $catalogdata;
	}

	public function productCart($postdata, $productData){

		$product = Product::select('product_name', 'product_image', 'product_description', 'product_id')->where('product_id', $postdata['product_id'])->first();
		$bin_identification = $productData['kiosk']['bin_identification'];

		if(!empty($product)){
			$inventory = array(
				'product_id' 	=> (string)$product->product_id,
                'product_name' 	=> $product->product_name,
                'price' 		=> 50,
                'description' 	=> $product->product_description,
                'media' 		=> array(),
                'variant' 		=> array()	
			);

			$productVariant = ProductVariant::select('kiosk_product.kiosk_product_id', 'kiosk_product.product_variant_id', 'product_variants.variant_name', 'kiosk_product.price as variant_price', 'kiosk_product.bay_no', 'kiosk_product.quantity', 'product_variants.variant_sku')
			->rightjoin(with(new KioskProduct())->getTable(), 'product_variants.product_variant_id', 'kiosk_product.product_variant_id')
			->where('product_variants.product_id', $postdata['product_id'])
			->where('kiosk_product.kiosk__id', $productData['kiosk']['acc_kiosk_id'])
			->get()
			->all();

			foreach ($productVariant as $key => $variant) {
				
				$variantData = array(
					"variant_id" 	=> (string) $variant->product_variant_id,
					"variant_type" 	=> $variant->variant_sku,
					"variant_name" 	=> $variant->variant_name,
					"quantity" 		=> $variant->quantity,
					"bay_no"		=> $bin_identification[$variant->bay_no-1],
					"price"			=> $variant->variant_price
				);
				array_push($inventory['variant'], $variantData);
			}
			
			if($product->product_image != ''){
				$inventory['media'][] = [
					"media_url" => $product->product_image,
					"media_id"	=> 0
				];
			}

			$productImage = ProductImage::where('product_id', $postdata['product_id'])
				->select('image_url as media_url', 'product_image_id as media_id')
				->orderBy('product_image_id', 'desc')
				->get();
			if($productImage->count() > 0){
				// $inventory['media'] = $productImage->toArray();
				foreach ($productImage->toArray() as $key => $value) {
					array_push($inventory['media'], [
						"media_url" => $value['media_url'],
						"media_id"	=> (string)$value['media_id']
					]);
				}				
			}

			$productData['inventory'] = $inventory;

			if (!empty($productData['cart_id'])) {

				$getJourneyId = Cart::select('journey_id')->where('cart_id', $productData['cart_id'])->first();
	            if(!empty($getJourneyId)){
	                $insertevent = array(
		                'journey_step_dt' 	=> config('app.CURRENTEPOCH') ,
		                'journey_step_name' => 'product',
		                'journey__id' 		=> $getJourneyId->journey_id
		            );

		            if (isset($postdata['gender']) && !empty($postdata['gender'])) {
		                $insertevent['journey_gender'] = $postdata['gender'] === "Male" ? 'M' : ($postdata['gender'] === "Female" ? 'F' : 'O');
		            } else {
		                $insertevent['journey_gender'] = null;
		            }

		            $insertevent['journey_age_group'] = (isset($postdata['age']) && !empty($postdata['age'])) ? $this->get_age_group($postdata['age']) : null;

		            if (isset($postdata['emotion']) && !empty($postdata['emotion'])) {
		                $insertevent['journey_emotion_json'] = preg_replace('/\\\"/', "\"", $postdata['emotion']);
		                $insertevent['journey_emotion_json'] = is_array($insertevent['journey_emotion_json']) ? json_encode($insertevent['journey_emotion_json']) : $insertevent['journey_emotion_json']; 
		            } else {
		                $insertevent['journey_emotion_json'] = null;
		            }

		            JourneyStep::create($insertevent);		            
	            }
			}

			if (!empty($catalogdata['customer_id'])) {
	            //$customerdata['photo']             = $postdata['image'];
	            $customerdata['customer_gender'] 	= $insertevent['journey_gender'];
	            $customerdata['customer_age_group'] = $insertevent['journey_age_group'];
	            // $customerdata['emotion'] = $insertevent['emotion'];

	            Customer::where('customer_id', $catalogdata['customer_id'])->update($customerdata);
	        }

	        return $productData;
		}else{
			return "no_found";
		}		
	}

	public function get_existing_customer($customer_id){
		$lastnewsLettcustid = 0;
        if (!empty($customer_id) && $customer_id != NULL) {
            $getOptinId = KioskOptin::select('kiosk_optin_id')->where('customer_id', $customer_id)->first();
			if($getOptinId){
				$lastnewsLettcustid = $getOptinId->kiosk_optin_id;
			}            
        }

        $customer = Customer::select('customer_email')->where('customer_id', $customer_id)->first();
        //$email = get_object(TB_CUSTOMERS, 'email', 'customer_id', $customer_id);
        $newCustomer = array(
            'opt_in_id' 	=> ($lastnewsLettcustid >= 1 ? $lastnewsLettcustid : 0),
            'customer_id' 	=> $customer_id,
            'email' 		=> $customer->customer_email,
            'created_on' 	=> config('app.CURRENTEPOCH')
        );
        return $newCustomer;
	}

	public function newCart($customer, $registerdata, $dont_create_cart){
		 /* Yes Create cart if N */
        if (strtoupper($dont_create_cart) == 'N') {
            $journeyinsert = array(
                'customer_id' => $customer['customer_id'],
                'kiosk_id' => $registerdata['kiosk']['acc_kiosk_id'],
                'created_at' => config('app.CURRENTEPOCH')
            );
            $journey = Journey::create($journeyinsert);
            if($journey){
            	$cartData = array(
            		'journey_id' => $journey->journey_id,
            		'product_variant_id' => null,
            		'product_qty' => 0
            	);
            	$cart = Cart::create($cartData);
            	if($cart){
        			$lastcartid = $cart->cart_id;
            	}else{
            		$lastcartid = null;
            	}
            }else{
            	$lastcartid = null;
            }

        } else {
            $lastcartid = null;
        }

        $registerdata['customer_id'] = (string) $customer['customer_id'];
        $registerdata['cart_id'] = (string) $lastcartid;

        return $registerdata;
	}

	public function get_age_group($getage) {
        //return $getage;
        switch ($getage) {
            case ($getage >= 50):
                $age_group = 'Seniors';
                break;
            case ($getage < 50 && $getage >= 21):
                $age_group = 'Adult';
                break;
            case ($getage < 21 && $getage >= 13):
                $age_group = 'Young Adult';
                break;
            case ($getage == 100 || $getage <= 13):
                $age_group = 'Unknown';
                break;
            default:
                $age_group = 'Unknown';
                break;
        }
        return $age_group;
    }

    public function getCartJourney($cart_id){
    	$jouerney = Cart::rightjoin(with(new JourneyStep())->getTable(),'journey_steps.journey__id','carts.journey_id')
    					->select('journey_steps.journey_step_name')
						->where('carts.cart_id', $cart_id)
						->whereIn('journey_steps.journey_step_name',['checkout','abandon'])
						->get();
		if($jouerney->count() > 0){
			$step = $jouerney->all()->toArray();
			return array_column($step, 'journey_step_name');
		}else{
			return false;
		}
    }

    public function changeProductBay($input, $accountData){
		// dd($accountData['kiosk']);
    	$kiosk_id 	= $accountData['kiosk']['acc_kiosk_id'];
		$bins 		= $accountData['kiosk']['machine_bins']; 
    	$bays 		= $accountData['kiosk']['bin_identification'];

		if(!in_array($input['bay_number'], $bays)){
			return "invalid_bay";
    	}else{
    		$bayIndex = '';
    		$key = array_search($input['bay_number'], $bays);
                    
            if ($key !== false) {
                $bayIndex = $key; // Found...
			}
    	}

    	$bayIndex = ($bayIndex + 1);

		if($input['product_variant_id'] == ''){
			$bayVariants = KioskProduct::select('kiosk_product_id')
				->where('kiosk_product.bay_no', $bayIndex)
				->where('kiosk_product.kiosk__id', $kiosk_id)
				->get();

			if($bayVariants->count() > 0){
				$bayVariant 		= $bayVariants->toArray();
				$kiosk_product_id 	= array_column($bayVariant, 'kiosk_product_id');
				KioskProduct::whereIn('kiosk_product_id', $kiosk_product_id)->delete();
				return "product_remove";
			}			
		}else{
			// get product variant details
			$checkVar = ProductVariant::select('product_variants.*', 'products.product_name', 'products.product_image')
			->join('products', 'products.product_id', '=', 'product_variants.product_id')
			->join('kiosks', 'kiosks.account_id', '=', 'products.account_id')
			->where('product_variants.product_variant_id', $input['product_variant_id'])
			->first(); 
			if($checkVar == null){
				return "variant_error";
			}
		}
		
    	$kioskData = KioskModel::where('kiosk_model_id', $accountData['machine']['machine_model_id'])->first();

    	if(strtolower($kioskData->model_type) == 'vending_machine' || strtolower($kioskData->model_type) == "vending"){
    		
			$bayVariants = KioskProduct::select('kiosk_product_id')
				->where('kiosk_product.bay_no', $bayIndex)
				->where('kiosk_product.kiosk__id', $kiosk_id)
				->get();

			if($bayVariants->count() > 0){
				$bayVariant 		= $bayVariants->toArray();
				$kiosk_product_id 	= array_column($bayVariant, 'kiosk_product_id');
				KioskProduct::whereIn('kiosk_product_id', $kiosk_product_id)->delete();
			}

			if($input['product_variant_id'] == ''){
				return "product_remove";
			} else{
				$checkProductVariant = ProductVariant::where('product_variant_id', $input['product_variant_id'])->get();

	    		if($checkProductVariant->count() > 0){
	    			$productVariant = $checkProductVariant->first();

	    			$kioskProductData = array(
	    				'kiosk__id' 			=> $kiosk_id,
	    				'product_variant_id' 	=> $input['product_variant_id'],
	    				'bay_no' 				=> $bayIndex,
	    				'quantity' 				=> 0,
	    				'price' 				=> $productVariant->variant_price
	    			);
	    			
					$kioskProduct = KioskProduct::create($kioskProductData);
	    			if($kioskProduct){
	    				return 1;
	    			}else{
	    				return 0;
	    			}
	    		}else{
	    			return "variant_error";
	    		}
			}
    	}else{
    		return "machine_error";
    	}
    }

    public function changeProductQty($input, $accountData){
    	$kiosk_id 	= $accountData['kiosk']['acc_kiosk_id']; 
    	$bins 		= $accountData['kiosk']['machine_bins']; 
    	$bays 		= $accountData['kiosk']['bin_identification']; 

    	if(!in_array($input['bay_no'], $bays)){
    		return "invalid_bay";
    	}else{
    		$bayIndex = '';
    		$key = array_search($input['bay_no'], $bays);
                    
            if ($key !== false) {
                $bayIndex = $key; // Found...
			}
    	}

    	$bayIndex = ($bayIndex + 1);
    	$updatQty = KioskProduct::where('kiosk_product.bay_no', $bayIndex)
			->where('kiosk_product.kiosk__id', $kiosk_id)
			->where('kiosk_product.product_variant_id', $input['product_variant_id'])
			->first();

    	if($updatQty){
			KioskProduct::where('kiosk_product.bay_no', $bayIndex)
			->where('kiosk_product.kiosk__id', $kiosk_id)
			->where('kiosk_product.product_variant_id', $input['product_variant_id'])
			->update(['quantity' => $input['quantity']]);

    		return 1;
    	}else{
    		return 0;
    	}
    }

	public function getAdvertisements($postdata, $catalogdata){

		$accountData = Account::where('account_id', $catalogdata['account_id'])->first();
		if($accountData->account_type == 'std'){
			$AdvertData = Ad::where('account_id', $catalogdata['account_id']);

			if (isset($postdata['ad_type']) && !empty($postdata['ad_type'])) {
				$AdvertData = $AdvertData->where('ad_type', $postdata['ad_type']);
			}

			if (isset($postdata['ad_gender']) && !empty($postdata['ad_gender'])) {
				$AdvertData = $AdvertData->where('ad_gender', $postdata['ad_gender']);
			}

			if (isset($postdata['ad_age']) && !empty($postdata['ad_age'])) {
				$AdvertData = $AdvertData->where('ad_age_group', $postdata['ad_age']);
			}
		}else{
			$accountID[] = (int)$catalogdata['account_id'];
			array_push($accountID, $accountData->account_id_parent);

			$AdvertData = Ad::select('ads.ad_id', 'ads.ad_title', 'ads.ad_type', 'ads.account_id', 'ads.ad_data',
				DB::raw('IF(myadvertisement.advertisement_id = ads.ad_id, myadvertisement.status, ads.ad_status) 
				AS ad_status'),
				DB::raw('IF(myadvertisement.advertisement_id = ads.ad_id, myadvertisement.age, ads.ad_age_group) 
				AS ad_age_group'),
				DB::raw('IF(myadvertisement.advertisement_id = ads.ad_id, myadvertisement.gender, ads.ad_gender) 
				AS ad_gender')
			)
			->leftJoin('myadvertisement', 'ads.ad_id', '=', 'myadvertisement.advertisement_id')
			->whereIn('ads.account_id', $accountID);

			if (isset($postdata['ad_type']) && !empty($postdata['ad_type'])) {
				$AdvertData = $AdvertData->where('ads.ad_type', $postdata['ad_type']);
			}

			if (isset($postdata['ad_gender']) && !empty($postdata['ad_gender'])) {
				$AdvertData = $AdvertData->where('ads.ad_gender', $postdata['ad_gender']);
			}

			if (isset($postdata['ad_age']) && !empty($postdata['ad_age'])) {
				$AdvertData = $AdvertData->where('ads.ad_age_group', $postdata['ad_age']);
			}
		}

		$getAdvert = $AdvertData->get();

		$getAdvertData = [];
		if(count($getAdvert) > 0){
			foreach ($getAdvert as $key => $value) {
				array_push($getAdvertData, [
                    'ad_id' 		=> $value->ad_id,
                    'ad_title' 		=> $value->ad_title,
                    'ad_type' 		=> $value->ad_type,
                    'ad_data' 		=> $value->ad_data,
                    'ad_time' 		=> '',
                    'ad_gender' 	=> $value->ad_gender,
                    'ad_age'	 	=> $value->ad_age_group,
                    'ad_emotion' 	=> ''
				]);
			}
		}

		$catalogdata['advertisement'] = $getAdvertData;

		return $catalogdata;
	}
}	