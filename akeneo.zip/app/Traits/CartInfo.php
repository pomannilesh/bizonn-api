<?php

namespace App\Traits;

use Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;

use App\Models\Journey;
use App\Models\JourneyStep;

use App\Models\Cart;
use App\Models\Customer;

use App\Models\Promo;
use App\Models\Product;
use App\Models\ProductVariant;

use App\Models\Orders;

use App\Models\KioskOptin;
use App\Models\KioskProduct;
use App\Models\Kiosk;

use App\Models\AccountSetting;
use App\Models\Account;

use App\Models\User;

use App\Mail\CustomerMail;
use App\Mail\LowInventoryMail;
use Illuminate\Support\Facades\Mail;

trait CartInfo {

    public function getCartDetails($input) {
        $cartDetails = Journey::join('carts', 'carts.journey_id', 'journeys.journey_id')
        ->where('journeys.kiosk_id', $input['kiosk_id'])
        ->where('carts.cart_id', $input['cart_id'])
        ->first();

        return $cartDetails;
    }

    public function getJourneyStepDetails($input){
        $journeyStepDetails = Journey::join('carts', 'carts.journey_id', '=', 'journeys.journey_id')
            ->join('journey_steps', 'journey_steps.journey__id', '=', 'journeys.journey_id')
            ->where('journeys.kiosk_id', $input['kiosk_id'])
            ->where('carts.cart_id', $input['cart_id'])
            ->whereIn('journey_step_name', ['checkout', 'abandon'])
            ->first();
        return $journeyStepDetails;
    }

    public function checkPromo($input, $registerdata){
        $customerDetails = Customer::where('customer_email', $input['customer_email'])->first();
        $promos = Promo::rightJoin('kiosk_promos','kiosk_promos.promo_id','=','promos.promo_id')
            ->where(['promos.promo_status' => 'Y', 'promos.account_id' => $input['account_id'], 'promos.promo_code' => $input['promo_code']])
            ->where('kiosk_promos.kiosk_id',$input['kiosk_id'])
            ->first();
        if(!empty($customerDetails) && !empty($promos)){
            $cartcustomerdata['cart_id'] = $input['cart_id'];
            $cartcustomerdata['customer_id'] = $customerDetails->customer_id;
            $cartcustomerdata['kiosk_id'] = $input['kiosk_id'];

            return $cartcustomerdata;
        } else {
            return NULL;
        }
    }

    public function storeCart($postdata, $registerdata, $cartdata){
        $postdata['name'] = 'addtocart';
        // update data into cart table
        $cartSearchInput['cart_id']         = $postdata['cart_id'];
        $cartInput['product_variant_id']    = $postdata['variant_id'];
        $cartInput['product_qty']           = $postdata['quantity'];
        
        if(isset($postdata['bay_number']) && $postdata['bay_number'] !=''){
            $kiosk = Kiosk::where('kiosk_id', $registerdata['kiosk']['acc_kiosk_id'])->first();
            $bins = $kiosk->template_bin_identity;
            if($bins != ''){
                $binsArray = explode(',', $bins);
                $binIndex = array_search($postdata['bay_number'], $binsArray, true);
                $cartInput['bin_no'] = $binIndex + 1;
            }
        }

        // get product variant details
        $productVariant = ProductVariant::select('product_variants.*', 'products.product_name', 'products.product_status', 'products.product_image', 'product_image.product_image_id', 'product_image.image_url', 'kiosk_product.bay_no', 'kiosk_product.price')
        ->join('products', 'products.product_id', '=', 'product_variants.product_id')
        ->leftJoin('product_image', 'product_image.product_id', '=', 'product_variants.product_variant_id')
        ->join('kiosk_product', 'kiosk_product.product_variant_id', '=', 'product_variants.product_variant_id')
        ->where('product_variants.product_variant_id', $postdata['variant_id'])
        ->where('kiosk_product.bay_no', $cartInput['bin_no'])
        ->where('kiosk_product.quantity', '!=', 0)
        ->first();
        
        if($productVariant){

                Cart::updateOrCreate($cartSearchInput, $cartInput);
                $journeyDetails = Journey::find($cartdata->journey_id);

                if(isset($productVariant->product_image) && $productVariant->product_image == ''){
                    $media_id   = $productVariant->product_image_id;
                    $media_url  = $productVariant->image_url;
                }else{
                    $media_id   = 0;
                    $media_url  = $productVariant->product_image;
                }

                $variantdata[] = array(
                    'variant_id'    => (string)$productVariant->product_variant_id,
                    'product_id'    => (string)$productVariant->product_id,
                    'product_name'  => $productVariant->product_name,
                    'price'         => $productVariant->price,
                    'variant_name'  => $productVariant->variant_name,
                    'variant_type'  => $productVariant->variant_sku,
                    'quantity'      => (string) $postdata['quantity'],
                    'bay_no'        => $productVariant->bay_no,
                    'media_id'      => $media_id,
                    'media_url'     => $media_url
                );

                $customerDetails = $this->getCustomer($cartdata->customer_id);

                $addtocartdata['account_id']    = (string)$registerdata['account_id'];
                $addtocartdata['cart_id']       = $postdata['cart_id'];
                $addtocartdata['customer_id']   = (string)$cartdata->customer_id;
                
                if(!empty($customerDetails)){
                    $addtocartdata['customer_email'] = $customerDetails->customer_email;
                }else{
                    $addtocartdata['customer_email'] = null;
                }

                $addtocartdata['cart']['created_on']    = $journeyDetails->created_at;
                $addtocartdata['cart']['subtotal']      = (string)$productVariant->price;

                $subtotal   = $productVariant->price;
                $discount   = $tax = $stripe_fee = 0;
                $total      = $productVariant->price;

                // get order details
                $ordersdata = $this->getOrder($postdata['cart_id']);
                if(!empty($ordersdata)){
                    if($ordersdata->promo_id=='' || $ordersdata->promo_id == null){
                        $addtocartdata['cart']['promotion_id'] = "0";
                    }else{
                        $addtocartdata['cart']['promotion_id'] = $ordersdata->promo_id;
                    }
                    
                    $promo = Promo::where('promo_id',$ordersdata->promo_id)->first();
                    if(!empty($promo)){
                        $discount   = ($subtotal * (int)$promo->promo_discount / 100 );
                        $total      = $total - $discount;
                    }

                    if (!empty($registerdata['kiosk']['tax_yn']) && $registerdata['kiosk']['tax_yn'] != 'N') {        
                        if (!empty($registerdata['kiosk']['tax_rate']) && $registerdata['kiosk']['tax_rate'] != 0 ){
                            $tax    = ($subtotal * $registerdata['kiosk']['tax_rate'] / 100 );
                            $total  = $total + $tax;         
                        }
                    }

                    // update order data
                    $orders = Orders::find($ordersdata->order_id);
                    $orders->order_subtotal         = $subtotal;
                    $orders->order_discount_value   = $discount;
                    $orders->order_tax              = $tax;
                    $orders->order_total            = $total;
                    $orders->save();
                }else{
                    $addtocartdata['cart']['promotion_id'] = "0";
                    
                    // create entry in order table
                    $insertorderdata = array(
                        'journey_id'        => $cartdata->journey_id,
                        'cart_id'           => $postdata['cart_id'],
                        'created_at'        => round(microtime(true) * 1000),
                        'order_subtotal'    => $subtotal,
                        'order_discount_value' => $discount,
                        'order_tax'         => $tax,
                        'order_total'       => $total,
                        'dispensed_yn'      => 'N'
                    );

                    $ordersdata = Orders::create($insertorderdata);
                }

                $addtocartdata['cart']['discount']      = (string)$discount;
                $addtocartdata['cart']['tax']           = (string)$tax;
                $addtocartdata['cart']['stripe_fee']    = (string)$stripe_fee;
                $addtocartdata['cart']['total']         = (string)$total;
                $addtocartdata['cart']['receipt_yn']    = 'N';
                $addtocartdata['cart']['variantdetails'] = $variantdata;

                if (!empty($addtocartdata)) {
                    // Add data into journey step table
                    $journeyStepInput['journey__id']        = $cartdata->journey_id;
                    $journeyStepInput['journey_step_name']  = 'cartadd';
                    $journeyStepInput['journey_age_group']  = (isset($postdata['age']) && !empty($postdata['age'])) ? $this->getAgeGroup($postdata['age']) : null;
                    
                    if (isset($postdata['gender']) && !empty($postdata['gender']) && $postdata['gender'] != '') {
                        $journeyStepInput['journey_gender'] = $postdata['gender'] === "Male" ? 'M' : ($postdata['gender'] === "Female" ? 'F' : 'O');
                    } else {
                        $journeyStepInput['journey_gender'] = null;
                    }

                    if (isset($postdata['emotion']) && !empty($postdata['emotion'])) {
                        $journeyStepInput['journey_emotion_json'] = preg_replace('/\\\"/', "\"", $postdata['emotion']);
                        $journeyStepInput['journey_emotion_json'] = is_array($journeyStepInput['journey_emotion_json']) ? json_encode($journeyStepInput['journey_emotion_json']) : $journeyStepInput['journey_emotion_json'];
                    } else {
                        $journeyStepInput['journey_emotion_json'] = null;
                    }
                    $journeyStepInput['journey_step_dt'] = round(microtime(true) * 1000);
                    JourneyStep::create($journeyStepInput);
                    
                    // update data in customer table
                    if (!empty($cartdata->customer_id)) {
                        $customerdata['account_id'] = $registerdata['account_id'];
                        if (isset($postdata['gender']) && !empty($postdata['gender']) && $postdata['gender'] != '') {
                            $customerdata['customer_gender'] = $postdata['gender'] === "Male" ? 'M' : ($postdata['gender'] === "Female" ? 'F' : 'O');
                        } else {
                            $customerdata['customer_gender'] = null;
                        }
                        $customerdata['customer_age_group'] =  (isset($postdata['age']) && !empty($postdata['age'])) ? $this->getAgeGroup($postdata['age']) : null;
                        $customerdata['modified_at'] = round(microtime(true) * 1000);
                        $searchInput['customer_id'] = $cartdata->customer_id;
                        Customer::updateOrCreate($searchInput,$customerdata);
                    }
                }

                return $addtocartdata;
        }else{

            // get product variant details
            $productVariant = ProductVariant::select('product_variants.*', 'kiosk_product.bay_no', 'kiosk_product.quantity')
            ->join('kiosk_product', 'kiosk_product.product_variant_id', '=', 'product_variants.product_variant_id')
            ->where('product_variants.product_variant_id', $postdata['variant_id'])
            ->first();
            if($productVariant){

                if((int)$productVariant->bay_no != (int)$cartInput['bin_no']){
                    $addtocartdata['status']        = 'invalid_bay';
                    $addtocartdata['variant_id']    = NULL;
                    return $addtocartdata;
                }

                if((int)$postdata['quantity'] > (int)$productVariant->quantity){
                    $addtocartdata['status']        = 'quantity';
                    $addtocartdata['variant_id']    = NULL;
                    return $addtocartdata;
                }
            }

            $addtocartdata['status']        = 'Variant';
            $addtocartdata['variant_id']    = NULL;
            return $addtocartdata;
        }
    }

    // Calculate Age Group from age
    public function getAgeGroup($getage) {
        switch ($getage) {
            case ($getage >= 50):
                $age_group = 'Seniors';
                break;
            case ($getage < 50 && $getage >= 21):
                $age_group = 'Adult';
                break;
            case ($getage < 21 && $getage >= 13):
                $age_group = 'Young Adult';
                break;
            case ($getage == 100 || $getage <= 13):
                $age_group = 'Unknown';
                break;
            default:
                $age_group = 'Unknown';
                break;
        }
        return $age_group;
    } 

    public function abandonCart($postdata, $registerdata, $cartdetails){
        $carts = Cart::join('journey_steps', 'journey_steps.journey__id', '=', 'carts.journey_id')
        ->where('cart_id', $cartdetails->cart_id)
        ->where('journey_step_name','abandon')
        ->first();

        if(empty($carts)){
            // Add data into journey step table
            $journeyStepInput['journey__id']        = $cartdetails->journey_id;
            $journeyStepInput['journey_step_name']  = 'abandon';
            $journeyStepInput['journey_age_group']  = (isset($postdata['age']) && !empty($postdata['age'])) ? $this->getAgeGroup($postdata['age']) : null;

            if (isset($postdata['gender']) && !empty($postdata['gender']) && $postdata['gender'] != '') {
                $journeyStepInput['journey_gender'] = $postdata['gender'] === "Male" ? 'M' : ($postdata['gender'] === "Female" ? 'F' : 'O');
            } else {
                $journeyStepInput['journey_gender'] = null;
            }

            if (isset($postdata['emotion']) && !empty($postdata['emotion'])) {
                $journeyStepInput['journey_emotion_json'] = preg_replace('/\\\"/', "\"", $postdata['emotion']);
                $journeyStepInput['journey_emotion_json'] = is_array($journeyStepInput['journey_emotion_json']) ? json_encode($journeyStepInput['journey_emotion_json']) : $journeyStepInput['journey_emotion_json'];
            } else {
                $journeyStepInput['journey_emotion_json'] = null;
            }

            $journeyStepInput['journey_step_dt'] = round(microtime(true) * 1000);
            JourneyStep::create($journeyStepInput);

            // update cart table
            $updateOrderInput['order_subtotal']         = null;
            $updateOrderInput['order_discount_value']   = null;
            $updateOrderInput['order_txn_fees']         = null;
            $updateOrderInput['order_tax']              = null;
            $updateOrderInput['order_total']            = null;
            $updateOrderInput['promo_id']               = null;
            $updateOrderInput['dispensed_yn']           = 'N';

            // get product variant details
            $productVariant = ProductVariant::select('product_variants.*', 'kiosk_product.price')
            ->join('kiosk_product', 'kiosk_product.product_variant_id', '=', 'product_variants.product_variant_id')
            ->where('product_variants.product_variant_id', $cartdetails->product_variant_id)
            ->where('kiosk_product.product_variant_id', $cartdetails->product_variant_id)
            ->where('kiosk_product.bay_no', $cartdetails->bin_no)
            ->where('kiosk_product.quantity', '!=', 0)
            ->first();
            if($productVariant){
                $updateOrderInput['order_subtotal'] = $productVariant->price;
                $updateOrderInput['order_total']    = $productVariant->price;
            }      

            Orders::where('cart_id', $cartdetails->cart_id)->update($updateOrderInput);

            // update data in customer table
            if (!empty($cartdetails->customer_id)) {
                $customerdata['account_id'] = $registerdata['account_id'];
                
                if (isset($postdata['gender']) && !empty($postdata['gender']) && $postdata['gender'] != ''){
                    $customerdata['customer_gender'] = $postdata['gender'] === "Male" ? 'M' : ($postdata['gender'] === "Female" ? 'F' : 'O');
                } else {
                    $customerdata['customer_gender'] = null;
                }

                $customerdata['customer_age_group'] = (isset($postdata['age']) && !empty($postdata['age'])) ? $this->getAgeGroup($postdata['age']) : null;
                $customerdata['modified_at']        = round(microtime(true) * 1000);
                $searchInput['customer_id']         = $cartdetails->customer_id;
                Customer::updateOrCreate($searchInput, $customerdata);
            }
        }
        
        $abandondata            = array();
        $abandondata['status']  = "TRUE";
        return $abandondata;
    }

    public function removeFromCart($postdata, $registerdata, $cartdetails){
        $postdata['name'] = 'remove';
        if($cartdetails->product_variant_id == '' || $cartdetails->product_variant_id == null){
            $addtocartdata['status'] = 'removed';
            return $addtocartdata;
        }else{
            $checkVariant = Cart::where(['product_variant_id' => $postdata['variant_id'], 'cart_id' => $postdata['cart_id']])->first();
            if($checkVariant == null){
                $addtocartdata['status'] = 'INVALID_VARIANT';
                return $addtocartdata;
            }
        }

        // update cart table
        $searchInput['cart_id']                 = $postdata['cart_id'];
        $updateCartInput['product_variant_id']  = null;
        $updateCartInput['product_qty']         = null;
        Cart::updateOrCreate($searchInput, $updateCartInput);

        // update cart table
        $updateOrderInput['order_subtotal']         = null;
        $updateOrderInput['order_discount_value']   = null;
        $updateOrderInput['order_txn_fees']         = null;
        $updateOrderInput['order_tax']              = null;
        $updateOrderInput['order_total']            = null;
        $updateOrderInput['promo_id']               = null;
        $updateOrderInput['dispensed_yn']           = 'N';

        Orders::where('cart_id', $postdata['cart_id'])->update($updateOrderInput);

        // remove entry from kios optin table
        if (!empty($postdata['customer_email'])) {
            $customerdata = Customer::where('customer_email', $postdata['customer_email'])->first();
            if (!empty($customerdata)) {
                if ($cartdetails->customer_id != $customerdata->customer_id) {
                    $customer_id = $cartdetails->customer_id;
                    Journey::where('journey_id', $cartdetails->journey_id)->update(['customer_id' => $customer_id]);

                    // delete recoed
                    Customer::where('customer_id',$customer_id)->delete();
                    KioskOptin::where('customer_id',$customer_id)->delete();
                }
            } else {
                Customer::where('customer_id', $cartdetails->customer_id)->update(['customer_email' => $postdata['customer_email']]);
            }
        }

        $customerDetails = $this->getCustomer($cartdetails->customer_id);
        $addtocartdata['account_id']    = $registerdata['account_id'];
        $addtocartdata['cart_id']       = $postdata['cart_id'];
        $addtocartdata['customer_id']   = (string)$cartdetails->customer_id;
         if(!empty($customerDetails)){
            $addtocartdata['customer_email'] = $customerDetails->customer_email;
        }else{
            $addtocartdata['customer_email'] = null;
        }
        $journeyDetails = Journey::find($cartdetails->journey_id);
        $addtocartdata['cart']['created_on']    = $journeyDetails->created_at;
        $addtocartdata['cart']['subtotal']      = "0";
        $addtocartdata['cart']['promotion_id']  = "0";
        $addtocartdata['cart']['discount']      = "0";
        $addtocartdata['cart']['tax']           = "0";
        $addtocartdata['cart']['stripe_fee']    = "0";
        $addtocartdata['cart']['total']         = "0";
        $addtocartdata['cart']['receipt_yn']    = 'N';
        $addtocartdata['cart']['variantdetails'] = [];
        return $addtocartdata;
    }

    public function applyPromo($postdata, $registerdata, $cartdetails){
        $promodata = Promo::leftJoin('kiosk_promos','kiosk_promos.promo_id','=','promos.promo_id')
            ->where(['promos.promo_status' => 'Y', 'promos.account_id' => $registerdata['account_id'], 'promos.promo_code' => $postdata['promo_code']])
            ->where('kiosk_promos.kiosk_id',$registerdata['kiosk']['acc_kiosk_id'])
            ->first();

        if (!empty($promodata)) {
            $counter = 0;

            if (!empty($promodata->account_id)) {
                if ($promodata->account_id == $postdata['account_id']) {
                    $counter = $counter + 1;
                    $postdata['promo_code']     = $promodata->promo_code;
                    $postdata['name']           = 'addpromo';
                    $postdata['discount']       = $promodata->promo_discount;
                    $postdata['promotion_id']   = $promodata->promo_id;
                    $postdata['coupon_code']    = $promodata->promo_code;
                }
            }

            if (!empty($postdata['discount']) && !empty($postdata['coupon_code'])) {
                $journeyDetails = Journey::find($cartdetails->journey_id);
                $cartdb = Cart::find($cartdetails->cart_id);
                if($cartdb->product_variant_id == '' || $cartdb->product_variant_id == null){
                    $addpromodata['status'] = "Promo";
                    return $addpromodata;
                }
        
                // get product variant details
                $productVariant = ProductVariant::select('product_variants.*','products.product_name','products.product_status','product_image.product_image_id','product_image.image_url','kiosk_product.bay_no','kiosk_product.price')
                ->join('products','products.product_id','=','product_variants.product_id')
                ->leftJoin('product_image','product_image.product_id','=','product_variants.product_id')
                ->join('kiosk_product','kiosk_product.product_variant_id','=','product_variants.product_variant_id')
                ->where('product_variants.product_variant_id', $cartdb->product_variant_id)
                ->first();
                $variantdata[] = array(
                    'variant_id'    => (string)$productVariant->product_variant_id,
                    'product_id'    => (string)$productVariant->product_id,
                    'product_name'  => $productVariant->product_name,
                    'price'         => $productVariant->price,
                    'variant_name'  => $productVariant->variant_name,
                    'variant_type'  => $productVariant->variant_sku,
                    'quantity'      => (string) $cartdb->product_qty,
                    'bay_no'        => $productVariant->bay_no,
                    'media_id'      => $productVariant->product_image_id,
                    'media_url'     => $productVariant->image_url,
                );  

                $customerDetails = $this->getCustomer($cartdetails->customer_id);

                $addpromodata['account_id']     = (string)$registerdata['account_id'];
                $addpromodata['cart_id']        = $postdata['cart_id'];
                $addpromodata['customer_id']    = (string)$cartdetails->customer_id;
                if(!empty($customerDetails)){
                    $addpromodata['customer_email'] = $customerDetails->customer_email;
                }else{
                    $addpromodata['customer_email'] = null;
                }
                $addpromodata['cart']['created_on']     = $journeyDetails->created_at;
                $addpromodata['cart']['subtotal']       = $productVariant->price;
                $addpromodata['cart']['promotion_id']   = (string)$postdata['promotion_id'];
                $subtotal = $total = $productVariant->price;
                $tax = $stripe_fee = 0;

                $discount   = round( ($subtotal * (int)$postdata['discount'] / 100 ), 2);
                $total      = $total - $discount;

                if (!empty($registerdata['kiosk']['tax_yn']) &&  $registerdata['kiosk']['tax_yn'] != 'N'){        
                    if (!empty($registerdata['kiosk']['tax_rate']) && $registerdata['kiosk']['tax_rate'] != 0 ) {        
                        $tax    = ($subtotal * (float)$registerdata['kiosk']['tax_rate'] / 100 );
                        $total  = $total + $tax;         
                    }
                }

                // $addpromodata['cart']['discount']    = (string)$postdata['discount'];
                $addpromodata['cart']['discount']       = (string)$discount;
                $addpromodata['cart']['tax']            = (string)$tax;
                $addpromodata['cart']['stripe_fee']     = (string)$stripe_fee;
                $addpromodata['cart']['total']          = (string)$total;
                $addpromodata['cart']['receipt_yn']     = 'N';
                $addpromodata['cart']['variantdetails'] = $variantdata;

                // update order table
                $updateOrderInput['order_subtotal']         = $subtotal;
                $updateOrderInput['order_discount_value']   = $discount;
                $updateOrderInput['order_txn_fees']         = null;
                $updateOrderInput['order_tax']              = $tax;
                $updateOrderInput['order_total']            = $total;
                $updateOrderInput['promo_id']               = $postdata['promotion_id'];
                $updateOrderInput['dispensed_yn']           = 'N';

                Orders::where('cart_id', $cartdetails->cart_id)->update($updateOrderInput);

                return $addpromodata;
            } else {
                $addpromodata['status'] = "Promo";
                $addpromodata['promo_code'] = NULL;
                return $addpromodata;
            }
        } else {
            $addpromodata['status'] = "Promo";
            $addpromodata['promo_code'] = NULL;
            return $addpromodata;
        }
    }

    public function checkoutCart($postdata, $registerdata, $cartdetails){
        if (!empty($postdata['customer_email'])) {
            $customerdata = Customer::where('customer_email', $postdata['customer_email'])->first();

            if (!empty($customerdata)) {
                if ($cartdetails->customer_id != $customerdata->customer_id) {
                    $customer_id            = $cartdetails->customer_id;
                    $journey                = Journey::find($cartdetails->journey_id);
                    $journey->customer_id   = $customerdata->customer_id;
                    $journey->save();

                    // delete from customer table
                    Customer::where('customer_id', $customer_id)->delete();
                }
            } else {
                Customer::where('customer_id', $cartdetails->customer_id)->update(['customer_email' => $postdata['customer_email'] ]);
            }
        }

        // get product variant price
        // $product_variants = ProductVariant::find($cartdetails->product_variant_id);
        // if($product_variants){
        //     if ($product_variants->variant_price != $postdata['cart_total']) {
        //         $checkoutdata['status'] = "Total";
        //         $checkoutdata['cart_id'] = NULL;
        //         return $checkoutdata;
        //     }
        // }

        $product_variants = Orders::where(['journey_id' => $cartdetails->journey_id, 'cart_id' => $cartdetails->cart_id])->first();
        if($product_variants){
            if ($product_variants->order_total != $postdata['cart_total']) {
                $checkoutdata['status']     = "Total";
                $checkoutdata['cart_id']    = NULL;
                return $checkoutdata;
            }
        }

        // get cart table data
        $cartdbdata = Cart::where('cart_id', $cartdetails->cart_id)->first();
        // check order table data
        $orderdata = Orders::where('cart_id', $cartdetails->cart_id)->first();
        if(!empty($orderdata)){
            // update inventory
            $kiosk_product = KioskProduct::where(['kiosk__id' => $registerdata['kiosk']['acc_kiosk_id'], 'product_variant_id' => $cartdbdata->product_variant_id])->first();
            $kiosk_product_qty = $kiosk_product->quantity;

            $updatedQty = $kiosk_product_qty - $cartdbdata->product_qty;
            $kioskProduct = KioskProduct::where(['kiosk__id' => $registerdata['kiosk']['acc_kiosk_id'], 'bay_no' => $cartdbdata->bin_no])->update(['quantity' => $updatedQty]);

            $updateorderdata = array(
                'order_transaction_ref' => !empty($postdata['txn_id']) ? $postdata['txn_id'] : null,
                'unique_identifier'     => (isset($postdata['unique_identifier']) && $postdata['unique_identifier'] != '' ? $postdata['unique_identifier'] : NULL),
                'receipt_yn'            => $postdata['send_receipt_yn'],
                'dispensed_yn'          => 'Y',
            );
            $searchOrderInput['order_id'] = $orderdata->order_id;
            Orders::updateOrCreate($searchOrderInput, $updateorderdata);
            $checkoutdata['order_id'] = (string)$orderdata->order_id;

            // Add data into journey step table
            $age_gen_emo_temp_array                 = array();
            $journeyStepInput['journey__id']        = $cartdetails->journey_id;
            $journeyStepInput['journey_step_name']  = 'checkout';
            $journeyStepInput['journey_age_group']  = $age_gen_emo_temp_array['age_group'] = (isset($postdata['age']) && !empty($postdata['age'])) ? $this->getAgeGroup($postdata['age']) : null;
            if (isset($postdata['gender']) && !empty($postdata['gender']) && $postdata['gender'] != '') {
                $journeyStepInput['journey_gender'] = $age_gen_emo_temp_array['gender'] = $postdata['gender'] === "Male" ? 'M' : ($postdata['gender'] === "Female" ? 'F' : 'O');
            } else {
                $journeyStepInput['journey_gender'] = null;
                $age_gen_emo_temp_array['gender']   = null;
            }

            $journeyStepInput['journey_step_dt'] = round(microtime(true) * 1000);
            if (isset($postdata['emotion']) && !empty($postdata['emotion'])) {
                $journeyStepInput['journey_emotion_json'] = $age_gen_emo_temp_array['emotion'] = preg_replace('/\\\"/', "\"", $postdata['emotion']);
                $journeyStepInput['journey_emotion_json'] = is_array($journeyStepInput['journey_emotion_json']) ? json_encode($journeyStepInput['journey_emotion_json']) : $journeyStepInput['journey_emotion_json'];
            } else {
                $journeyStepInput['emotion'] = $age_gen_emo_temp_array['emotion'] = null;
            }

            JourneyStep::create($journeyStepInput);

            if (!empty($cartdetails->customer_id)) {
                $update_customerdata = array();
                $update_customerdata['customer_gender']     = $age_gen_emo_temp_array['gender'];
                $update_customerdata['customer_age_group']  = $age_gen_emo_temp_array['age_group'];

                Customer::where('customer_id', $cartdetails->customer_id)->update($update_customerdata);
            }
             
            return $checkoutdata;
        }else{
            $checkoutdata['status'] = "Fail";
            return $checkoutdata;
        }
    }

    public function getOrder($cartId){
        $ordersdata = Orders::where('cart_id', $cartId)->first();
        return $ordersdata;
    }

    public function getCustomer($customerId){
        $customerdata = Customer::find($customerId);
        return $customerdata;
    }

    public function sendCustomerMail($orderID){
        
        // Get Order Details
        $OrderDetail = Orders::select(
            'orders.order_id',
            'orders.order_transaction_ref', 
            'orders.order_subtotal', 
            'orders.order_discount_value', 
            'orders.promo_id', 
            'orders.order_tax', 
            'orders.order_total',

            'carts.cart_id', 
            'carts.journey_id', 
            'carts.product_variant_id', 
            'carts.product_qty', 
            'carts.bin_no',

            'journeys.customer_id',
            'journeys.kiosk_id',

            'kiosks.kiosk_tax_rate',
            'kiosks.kiosk_street',
            'kiosks.kiosk_city',
            'kiosks.kiosks_state',
            'kiosks.kiosk_country',
            'kiosks.kiosk_zip',

            'product_variants.variant_name',
            'product_variants.variant_price',

            'products.product_name',

            'accounts.account_id',
            'accounts.account_name',
            'accounts.account_id_parent',

            'account_setting.account_logo',
            'account_setting.account_org_name',
            'account_setting.primany_color',
            'account_setting.receipt_custom_text_1',
            'account_setting.receipt_custom_text_2',
            'account_setting.include_survey_url',
            'account_setting.receipt_survey_url',

            'account_setting.receipt_sender_email',
            'account_setting.receipt_sender_password',
            'account_setting.receipt_sender_host',
            'account_setting.receipt_sender_port',
            
            'promos.promo_code',
            'customers.customer_email',

            DB::raw('null as parent_name'),
            DB::raw('null as parent_email_custom_text_1'),
            DB::raw('null as parent_include_servey_url'),
            DB::raw('null as parent_email_servey_url'),
        )
        ->leftJoin('carts', 'carts.cart_id', '=', 'orders.cart_id')
        ->leftJoin('journeys', 'journeys.journey_id', '=', 'carts.journey_id')
        ->leftJoin('customers', 'customers.customer_id', '=', 'journeys.customer_id')
        ->leftJoin('promos', 'promos.promo_id', '=', 'orders.promo_id')
        ->leftJoin('kiosks', 'kiosks.kiosk_id', '=', 'journeys.kiosk_id')
        ->leftJoin('account_setting', 'account_setting.account_id', '=', 'kiosks.account_id')
        ->leftJoin('accounts', 'accounts.account_id', '=', 'kiosks.account_id')
        ->leftJoin('product_variants', 'product_variants.product_variant_id', '=', 'carts.product_variant_id')
        ->leftJoin('products', 'products.product_id', '=', 'product_variants.product_id')
        ->where('orders.order_id', $orderID)
        ->first();

        if($OrderDetail){
            if($OrderDetail->account_id_parent != 0){
                $accontSetting = AccountSetting::where('account_id', $OrderDetail->account_id_parent)
                ->select('receipt_custom_text_1', 'receipt_custom_text_2', 'receipt_survey_url as email_servey_url', 'include_survey_url as include_servey_url')->first()->toArray();
                if($accontSetting){
                    $OrderDetail->parent_email_custom_text_1 = $accontSetting['receipt_custom_text_1'];
                    $OrderDetail->parent_include_servey_url  = $accontSetting['include_servey_url'];
                    $OrderDetail->parent_email_servey_url    = $accontSetting['email_servey_url'];
                }

                $account = Account::where('account_id', $OrderDetail->account_id_parent)->first()->toArray();
                if($account){
                    $OrderDetail->parent_name = $account['account_name'];
                }
            }

            try {
                // Setup mail.php
                $mailSetup = array(
                    'transport'     => 'smtp',
                    'host'          => $OrderDetail->receipt_sender_host,
                    'port'          => $OrderDetail->receipt_sender_port,
                    'encryption'    => 'tls',
                    'username'      => $OrderDetail->receipt_sender_email,
                    'password'      => $OrderDetail->receipt_sender_password,
                    'timeout'       => null,
                    'auth_mode'     => null,
                );

                $formSetup = array(
                    'address'   => $OrderDetail->receipt_sender_email, 
                    'name'      => ''
                );
                
                Config::set('mail.mailers.smtp', $mailSetup);
                Config::set('mail.from', $formSetup);
                
                $email = $OrderDetail->customer_email;
                Mail::to($email)->send(new CustomerMail($OrderDetail));
            } catch (\Throwable $th) {
                //throw $th;
            }            
        }        
    }

    public function sendLowInventoryEmail($accountDetails){
        $userEmail          = '';
        $mechineName        = '';
        $timeZone           = '';
        $lowInventoryNumber = 0;
        $binIdentification  = $accountDetails['kiosk']['bin_identification'];

        $getKiosk = Kiosk::where('kiosk_id', $accountDetails['kiosk']['acc_kiosk_id'])->first();
        if($getKiosk){
            $mechineName        = $getKiosk->kiosk_identifier;
            $lowInventoryNumber = $getKiosk->kiosk_low_inv_threshold;
            $timeZone           = $getKiosk->kiosk_timezone;

            $getUser = User::where('account_id', $accountDetails['account_id'])->first();
            if($getUser){
                $userEmail = $getUser->email;
            }
        }

        $getProduct = KioskProduct::select('kiosk_product.*', 'products.product_name')
        ->leftJoin('product_variants', 'product_variants.product_variant_id', '=', 'kiosk_product.product_variant_id')
        ->leftJoin('products', 'products.product_id', '=', 'product_variants.product_id')
        ->where('kiosk_product.kiosk__id', $accountDetails['kiosk']['acc_kiosk_id'])->get()->toArray();

        $tempArray          = array();
        $other_bay_array    = array();
        if( !empty($getProduct) ) {
            
            foreach ($getProduct as $key => $row) {
                // check product quantity is less than low_inventory_vending_number or equal to zero  then set it as level 1 
                if($row['bay_no'] != null && ($row['quantity'] < $lowInventoryNumber || $row['quantity'] == 0)) {
                    $row['bay_no']  = $binIdentification[$row['bay_no'] - 1];
                    $row['level']   = 1;
                    $tempArray[]    = $row;
                } else {
                    // this are not in low_inventory_vending_number
                    $row['level']       = 2;
                    $row['bay_no']      = $binIdentification[$row['bay_no'] - 1];
                    $other_bay_array[]  = $row;
                }                
            }
        }

        $tempArray = array_merge($tempArray, $other_bay_array);
        if(isset($tempArray) && count($tempArray) > 0){
            Account::where('account_id', $accountDetails['account_id'])->update(['notification_alert' => 'Y']);

            $data['org_name']       = $accountDetails['parameter']['org_name'];
            $data['machine_name']   = $mechineName;            
            $data['street']         = $accountDetails['kiosk']['street'];
            $data['city']           = $accountDetails['kiosk']['city'];
            $data['state']          = $accountDetails['kiosk']['state'];
            $data['country']        = $accountDetails['kiosk']['country'];
            $data['zip']            = $accountDetails['kiosk']['zip'];
            $data['username']       = $accountDetails['parameter']['user_name'];
            $data['low_product_list'] = $tempArray;
            $data['utc_time']       = Carbon::now()->timezone("$timeZone")->format('m-d-Y H:i:s');

            try {

                $accontSetting = AccountSetting::where('account_id', $accountDetails['account_id'])->first();

                // Setup mail.php
                $mailSetup = array(
                    'transport'     => 'smtp',
                    'host'          => $accontSetting->receipt_sender_host,
                    'port'          => $accontSetting->receipt_sender_port,
                    'encryption'    => 'tls',
                    'username'      => $accontSetting->receipt_sender_email,
                    'password'      => $accontSetting->receipt_sender_password,
                    'timeout'       => null,
                    'auth_mode'     => null,
                );
    
                $formSetup = array(
                    'address'   => $accontSetting->receipt_sender_email, 
                    'name'      => ''
                );
                
                Config::set('mail.mailers.smtp', $mailSetup);
                Config::set('mail.from', $formSetup);
                
                $email = $userEmail;
                Mail::to($email)->send(new LowInventoryMail($data));
            } catch (\Throwable $th) {
                // throw $th;
            } 
        }          
    }
}