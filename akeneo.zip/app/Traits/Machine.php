<?php

namespace App\Traits;

use Auth;

use App\Models\Kiosk;
use App\Models\Promo;
use App\Models\Journey;

trait Machine {

    public function updateMachineTemplate($input) {
        $kiosk = Kiosk::where('kiosk_identifier', $input['machine_identifier'])->first();
        if(!empty($kiosk)){
            $bin                = '';
            $templateData       = $input['templateData']['data'];
            $template_bin_count = count($templateData);
            foreach($templateData as $template){
                if($bin != ''){
                    $bin = $bin.',';
                }
                $bin = $bin.$template['binID'];
            }

            $updateKiosk = Kiosk::find($kiosk->kiosk_id);
            $updateKiosk->template_name         = $input['name'];
            $updateKiosk->template_description  = $input['description'];
            $updateKiosk->template_bin_count    = $template_bin_count;
            $updateKiosk->template_created_dt   = round(microtime(true) * 1000);
            $updateKiosk->template_bin_identity = $bin;
            $updateKiosk->template_json         = json_encode($input['templateData']);
            $updateKiosk->template_status       = 'N';
            $updateKiosk->save();

            $productdata = array(
                'template_id'           => $kiosk->kiosk_id,
                'machine_id'            => (string)$kiosk->kiosk_id,
                'template_name'         => $input['name'],
                'template_description'  => $input['description'],
                'bins'                  => $template_bin_count,
                'created_on'            => round(microtime(true) * 1000),
                'bin_identification'    => $bin,
                'template_json'         => $input['templateData'],
            );  

            return $productdata;   
        }
    }

    public function checkConsumption($input){
        $kiosk = Kiosk::where('kiosk_identifier', $input['machine_identifier'])->first();
        
        $cartDetails = Journey::join('orders', 'orders.journey_id', '=', 'journeys.journey_id')->where('journeys.kiosk_id', $kiosk->kiosk_id)->where('orders.unique_identifier', $input['user_identifier'])->first();
        $allow = 0;
        if(!empty($cartDetails)){
            if($cartDetails->unique_identifier == $input['user_identifier']){
                $hour_allow     = $kiosk->pos_consumption_period_hr;              
                $order_date     = $cartDetails->created_at; 
                $currentDate    = date('Y-m-d H:i:s');
                $date           = date('Y-m-d H:i:s', strtotime($currentDate . ' - '.$hour_allow.' hours'));
                $mydate         = strtotime($date) * 1000;
                
                if($order_date > $mydate){
                    $allow = $allow + 1;
                }                
            }
        }

        if($kiosk->pos_consumption_units > $allow){
            $flag =  true;
        } else{
            $flag =  false;
        }
        return $flag;
    }
}